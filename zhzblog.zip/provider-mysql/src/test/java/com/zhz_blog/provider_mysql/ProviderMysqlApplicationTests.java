package com.zhz_blog.provider_mysql;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProviderMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
