package com.zhz_blog.provider_mysql;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProviderMysqlApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProviderMysqlApplication.class, args);
	}

}
