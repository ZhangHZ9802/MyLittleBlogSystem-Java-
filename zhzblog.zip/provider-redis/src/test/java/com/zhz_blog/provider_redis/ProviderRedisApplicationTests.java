package com.zhz_blog.provider_redis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProviderRedisApplicationTests {

	@Test
	void contextLoads() {
	}

}
