package com.zhz_blog.provider_redis;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProviderRedisApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProviderRedisApplication.class, args);
	}

}
